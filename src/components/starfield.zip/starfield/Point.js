export class Point {
  constructor(x, y, size, glowing) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.glowing = glowing;
  }
}